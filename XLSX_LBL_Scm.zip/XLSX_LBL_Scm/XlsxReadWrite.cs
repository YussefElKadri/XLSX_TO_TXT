﻿using System;
using System.Data;
using System.IO;
using ExcelDataReader;
using System.Windows.Forms;

class XlsxReadWrite
{
	public string Nome { get; set; }
	public string XlsxText(string caminho)
	{
		string pasta = Directory.GetCurrentDirectory();
		string[] listaArquivosXLSX = Directory.GetFiles(pasta, "*.xlsx");
		string outputDirectory = pasta + @"\TXTs"; //Pasta de escrita

		foreach (var item in listaArquivosXLSX)
		{
			string excelFilePath = item; // Caminho xlxs
			Nome = Path.GetFileName(item);

			if (!Directory.Exists(outputDirectory))
			{
				Directory.CreateDirectory(outputDirectory);
			}

			try
			{
				using (var stream = File.Open(excelFilePath, FileMode.Open, FileAccess.Read))
				{
					using (var reader = ExcelReaderFactory.CreateReader(stream))
					{
						var result = reader.AsDataSet();

						// Declarando primeira planilha
						var dataTable = result.Tables[0];

						int cycleStartRow = -1;
						int fileIndex = 1;

						for (int row = 0; row < dataTable.Rows.Count; row++)
						{
							string firstCellValue = dataTable.Rows[row][0].ToString();

							if (firstCellValue == "0")
							{
								if (cycleStartRow != -1)
								{
									// Escreve o primeiro ciclo no arquivo de texto
									WriteCycleToFile(dataTable, cycleStartRow, row - 1, outputDirectory, fileIndex);
									fileIndex++;
								}

								cycleStartRow = row; // Marcador de inicio para o novo ciclo
							}
						}

						// Escreve o ultimo ciclo no arquivo de texto
						if (cycleStartRow != -1)
						{
							WriteCycleToFile(dataTable, cycleStartRow, dataTable.Rows.Count - 1, outputDirectory, fileIndex);
						}
					}
				}

				Console.WriteLine("Arquivos de texto criados co sucesso!");
			}
			catch (Exception ex)
			{
				Console.WriteLine($"Um erro foi encontrato: {ex.Message}");
			}
		}

		foreach (var item in listaArquivosXLSX)
		{
			File.Delete(item);
		}

		return caminho;
	}

	public void WriteCycleToFile(DataTable dataTable, int startRow, int endRow, string outputDirectory, int fileIndex)
	{
		string novoNome = Nome.Replace(".xlsx", "");
		string outputFilePath = Path.Combine(outputDirectory, $"{novoNome}#{fileIndex.ToString().PadLeft(2, '0')}.txt");
		int cont = 0;
		string Comp;
		string Larg;
		string Esp;

		using (StreamWriter writer = new StreamWriter(outputFilePath))
		{
			for (int row = startRow; row <= endRow; row++)
			{
				if (cont == 0)
				{
					// Escreve cabeçalho txt
					string c4 = dataTable.Rows[row][4].ToString();
					string[] c4split = c4.Split(':');

					for (int i = 0; i < c4split.Length; i++)
					{
						if (i == 1)
						{
							Comp = c4split[i].ToString().Split('x')[0].ToString();
							Larg = c4split[i].ToString().Split('x')[1].ToString();
							Esp = c4split[i].ToString().Split('x')[2].ToString();

							writer.WriteLine($"X{Comp.ToString().PadLeft(5, '0')}|Y{Larg.ToString().PadLeft(5, '0')}|Z{Esp.ToString().PadLeft(5, '0')}|");
						}
					}
				}
				else
				{
					// Escreve corpo txt
					string c1 = dataTable.Rows[row][0].ToString();
					string c2 = dataTable.Rows[row][1].ToString();
					string c3 = dataTable.Rows[row][2].ToString();
					string c4 = dataTable.Rows[row][3].ToString();
					string c5 = dataTable.Rows[row][4].ToString();
					string c6 = dataTable.Rows[row][5].ToString();
					string c7 = dataTable.Rows[row][6].ToString();
					string c8 = dataTable.Rows[row][7].ToString();
					string c9 = dataTable.Rows[row][8].ToString();
					string c10 = dataTable.Rows[row][9].ToString();
					string c11 = dataTable.Rows[row][10].ToString();
					string c12 = dataTable.Rows[row][11].ToString();
					string c13 = dataTable.Rows[row][12].ToString();
					string c14 = dataTable.Rows[row][13].ToString();
					string c15 = dataTable.Rows[row][14].ToString();
					string c16 = dataTable.Rows[row][15].ToString();
					string c17 = dataTable.Rows[row][16].ToString();
					string c18 = dataTable.Rows[row][17].ToString();
					writer.WriteLine($"X{c1.ToString().PadLeft(5, '0')}|Y{c2.ToString().PadLeft(5, '0')}|{c3}|{c4}|{c5}|{c6}|{c7}|{c8}|{c9}|{c10}|{c11}|{c12}|{c13}|{c14}|{c15}|{c16}|{c17}|{c18}");
				}
				cont++;
			}
		}
	}
}
