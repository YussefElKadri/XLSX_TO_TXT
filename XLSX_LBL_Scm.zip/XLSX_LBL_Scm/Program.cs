﻿using System;
using System.IO;
using System.Windows.Forms;

namespace XXL_To_SCX_Nanxing_2To1
{
	internal class Program
	{
		static void Main(string[] args)
		{
			//CHAMAR("NomeCompletoApp" ; "NomeCompletoPastaSemEspaco\*.*") // NANXING FCC

			DateTime dataatual = DateTime.Now;
			DateTime datavencimento = new DateTime(year: 2024, 07, 30, 23, 59, 00);
			int comparativodata = DateTime.Compare(dataatual, datavencimento);
			XlsxReadWrite NovaLeituraXLSX = new XlsxReadWrite();

			if (comparativodata <= 0)
			{
				if (args.Length > 0)
				{
					for (int i = 0; i < args.Length; i++)
					{
						string somentepasta = Path.GetDirectoryName(args[i]);
						NovaLeituraXLSX.XlsxText(somentepasta);
					}
				}
				else if (args.Length <= 0)
				{
					string pasta = Directory.GetCurrentDirectory();
					NovaLeituraXLSX.XlsxText(pasta);
				}
			}
			else
			{
				MessageBox.Show("TopSystem Software\nSem licença!\nEntrar em contato com o Desenvolvedor!\n(43) 9 9919-2981", "Atenção!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
			}
		}
	}
}


#region Temp
/*	
*/
#endregion